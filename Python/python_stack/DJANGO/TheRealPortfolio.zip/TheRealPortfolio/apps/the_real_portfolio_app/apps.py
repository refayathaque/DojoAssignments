from __future__ import unicode_literals

from django.apps import AppConfig


class TheRealPortfolioAppConfig(AppConfig):
    name = 'the_real_portfolio_app'
