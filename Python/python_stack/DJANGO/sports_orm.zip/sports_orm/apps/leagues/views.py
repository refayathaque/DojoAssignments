from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Count

from . import team_maker

def index(request):
	context = {
		# "leagues": League.objects.all(),
		# "teams": Team.objects.all(),
		# "players": Player.objects.all(),
        # ######
        # "leagues1" : League.objects.filter(sport__contains='baseball'),
        # "leagues2" : League.objects.filter(name__contains='women'),
        # "leagues3" : League.objects.filter(sport__contains='hockey'),
        # "leagues4" : League.objects.exclude(sport__contains='football'),
        # "leagues5" : League.objects.filter(name__contains='conference'),
        # "leagues6" : League.objects.filter(name__contains='Atlantic'),
        # ######
        # "teams1" : Team.objects.filter(location__contains='Dallas'),
        # "teams2" : Team.objects.filter(team_name__contains='Raptors'),
        # "teams3" : Team.objects.filter(location__contains='City'),
        # "teams4" : Team.objects.filter(team_name__startswith='T'),
        # "teams5" : Team.objects.all().order_by('location'), #'-location' for desc
        # "teams6" : Team.objects.all().order_by('-team_name'),
        # ######
        # "players1" : Player.objects.filter(last_name__contains='Cooper'),
        # "players2" : Player.objects.filter(first_name__contains='Joshua'),
        # "players3" : Player.objects.filter(last_name__contains='Cooper').exclude(first_name__contains='Joshua'),
        # "players4" : Player.objects.filter(first_name__contains='Alexander') | Player.objects.filter(first_name__contains='Wyatt')
        # ######
        # ######
        "teams7" : Team.objects.filter(league__name__contains='Atlantic Soccer Conference'),
        "players5" : Player.objects.filter(curr_team__team_name__contains='Penguins'),
        "players6" : Player.objects.filter(curr_team__league__name__contains='International Collegiate Baseball Conference'),
        "players7" : Player.objects.filter(curr_team__league__name__contains='American Conference of Amateur Football').filter(last_name__contains='Lopez'),
        "players8" : Player.objects.filter(curr_team__league__sport__contains='Football'),
        "teams8" : Team.objects.filter(curr_players__first_name__contains='Sophia'),
        "leagues7" : League.objects.filter(teams__curr_players__first_name__contains='Sophia'),
        "players9" : Player.objects.filter(last_name__contains='Flores').exclude(curr_team__team_name__contains='Roughriders'),
        "teams9" : Team.objects.filter(all_players__first_name__contains='Samuel').filter(all_players__last_name__contains='Evans'),
        "players10" : Player.objects.filter(all_teams__team_name__contains='Tiger-Cats'),
        "players11" : Player.objects.filter(all_teams__team_name__contains='Vikings').exclude(curr_team__team_name__contains='Vikings'),

        'jacob_gray' : Player.objects.filter(first_name='Jacob', last_name='Gray').exclude(all_teams__team_name='Colts'),
        # ^ doesn't work

        'players12' : Player.objects.filter(first_name__contains='Joshua').filter(all_teams__league__name__contains='Atlantic Federation of Amateur Baseball Players'),

        'teams10' : Team.objects.annotate(num_players=Count('all_players')),
        # ^ doesn't work

        'players13' : Player.objects.annotate(number_of_teams=Count('all_teams')).order_by('-number_of_teams')
        # ^ works? not sure...
    }

	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
